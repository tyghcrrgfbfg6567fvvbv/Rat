package com.crypto.coldMinnerPro.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;

public class ServiceUtil {

    /**
     * Checks if a service is running.
     *
     * @param context       the context.
     * @param serviceClass  the service class to check.
     * @return true if the service is running, false otherwise.
     */
    public static boolean isServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Starts the service if it is not already running.
     *
     * @param context       the context.
     * @param serviceClass  the service class to start.
     */
    public static void startServiceIfNotRunning(Context context, Class<?> serviceClass) {
        if (!isServiceRunning(context, serviceClass)) {
            Intent serviceIntent = new Intent(context, serviceClass);
            context.startService(serviceIntent);
        }
    }

    /**
     * Stops the service if it is running.
     *
     * @param context       the context.
     * @param serviceClass  the service class to stop.
     */
    public static void stopServiceIfRunning(Context context, Class<?> serviceClass) {
        if (isServiceRunning(context, serviceClass)) {
            Intent serviceIntent = new Intent(context, serviceClass);
            context.stopService(serviceIntent);
        }
    }

    /**
     * Restarts the service.
     *
     * @param context       the context.
     * @param serviceClass  the service class to restart.
     */
    public static void restartService(Context context, Class<?> serviceClass) {
        Intent serviceIntent = new Intent(context, serviceClass);
        context.stopService(serviceIntent);
        context.startService(serviceIntent);
    }

    /**
     * Toggles the service state.
     *
     * @param context       the context.
     * @param serviceClass  the service class to toggle.
     */
    public static void toggleService(Context context, Class<?> serviceClass) {
        Intent serviceIntent = new Intent(context, serviceClass);
        if (isServiceRunning(context, serviceClass)) {
            context.stopService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
}