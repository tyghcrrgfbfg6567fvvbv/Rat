package com.crypto.coldMinnerPro.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class SharedPrefManager {

    private static final String TAG = "SharedPrefManager";
    private static SharedPrefManager instance;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private static final String PREF_NAME = "CyberZoneAcademy";

    public SharedPrefManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        Log.d(TAG, "SharedPrefManager initialized with PREF_NAME: " + PREF_NAME);
    }

    // String methods
    public void set(String key, String value) {
        editor.putString(key, value);
        editor.apply();
        Log.d(TAG, "String set: " + key + " = " + value);
    }

    public String get(String key) {
        String value = sharedPreferences.getString(key, null);
        Log.d(TAG, "String get: " + key + " = " + value);
        return value;
    }

    // Boolean methods
    public void setB(String key, boolean value) {
        editor.putBoolean(key, value);
        editor.apply();
        Log.d(TAG, "Boolean set: " + key + " = " + value);
    }

    public boolean getB(String key) {
        boolean value = sharedPreferences.getBoolean(key, false);
        Log.d(TAG, "Boolean get: " + key + " = " + value);
        return value;
    }

    // Integer methods
    public void setInt(String key, int value) {
        editor.putInt(key, value);
        editor.apply();
        Log.d(TAG, "Integer set: " + key + " = " + value);
    }

    public int getInt(String key) {
        int value = sharedPreferences.getInt(key, 0);
        Log.d(TAG, "Integer get: " + key + " = " + value);
        return value;
    }

    // Float methods
    public void setFloat(String key, float value) {
        editor.putFloat(key, value);
        editor.apply();
        Log.d(TAG, "Float set: " + key + " = " + value);
    }

    public float getFloat(String key) {
        float value = sharedPreferences.getFloat(key, 0.0f);
        Log.d(TAG, "Float get: " + key + " = " + value);
        return value;
    }

    // Long methods
    public void setLong(String key, long value) {
        editor.putLong(key, value);
        editor.apply();
        Log.d(TAG, "Long set: " + key + " = " + value);
    }

    public long getLong(String key) {
        long value = sharedPreferences.getLong(key, 0);
        Log.d(TAG, "Long get: " + key + " = " + value);
        return value;
    }

    // Clear all preferences
    public void clear() {
        editor.clear();
        editor.apply();
        Log.d(TAG, "All preferences cleared.");
    }

    // Remove a specific key
    public void remove(String key) {
        editor.remove(key);
        editor.apply();
        Log.d(TAG, "Preference removed: " + key);
    }
}