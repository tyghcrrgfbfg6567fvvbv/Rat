package com.crypto.coldMinnerPro.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.util.Log;
import android.content.Context;
import android.provider.Settings;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.io.IOException;

public class NetworkUtil {
	
	private static final String TAG = NetworkUtil.class.getSimpleName();
	
	// Check if the device is connected to any network
	public static boolean isNetworkConnected(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
					NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
					return capabilities != null && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
					|| capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
					|| capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
				} else {
					android.net.NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
					return activeNetworkInfo != null && activeNetworkInfo.isConnected();
				}
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking network connection", e);
		}
		return false;
	}
	
	// Check if the device is connected via WiFi
	public static boolean isWifiConnected(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				android.net.NetworkInfo wifiInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
				return wifiInfo != null && wifiInfo.isConnected();
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking WiFi connection", e);
		}
		return false;
	}
	
	// Check if the device is connected via mobile data
	public static boolean isMobileDataConnected(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				android.net.NetworkInfo mobileInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
				return mobileInfo != null && mobileInfo.isConnected();
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking mobile data connection", e);
		}
		return false;
	}
	
	// Check if the device is connected via Bluetooth
	public static boolean isBluetoothConnected(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				android.net.NetworkInfo bluetoothInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_BLUETOOTH);
				return bluetoothInfo != null && bluetoothInfo.isConnected();
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking Bluetooth connection", e);
		}
		return false;
	}
	
	// Check if the device is connected via VPN
	public static boolean isVpnConnected(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
				return capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking VPN connection", e);
		}
		return false;
	}
	
	// Get the type of the currently active network
	public static String getActiveNetworkType(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
				if (capabilities != null) {
					if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
						return "WiFi";
					} else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
						return "Mobile";
					} else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
						return "Ethernet";
					} else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH)) {
						return "Bluetooth";
					} else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
						return "VPN";
					} else {
						return "Unknown";
					}
				}
			}
		} catch (Exception e) {
			Log.e(TAG, "Error getting active network type", e);
		}
		return "None";
	}
	
	// Check if airplane mode is enabled
	public static boolean isAirplaneModeOn(Context context) {
		try {
			if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
				// Airplane mode status cannot be checked before API 17
				return false;
			}
			return Settings.Global.getInt(context.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
		} catch (Exception e) {
			Log.e(TAG, "Error checking airplane mode", e);
		}
		return false;
	}
	
	// Check if the device is connected to a metered network
	public static boolean isNetworkMetered(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				return connectivityManager.isActiveNetworkMetered();
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking network metered status", e);
		}
		return false;
	}
	
	// Check if the device is connected to a roaming network
	public static boolean isNetworkRoaming(Context context) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			if (connectivityManager != null) {
				android.net.NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
				return activeNetworkInfo != null && activeNetworkInfo.isRoaming();
			}
		} catch (Exception e) {
			Log.e(TAG, "Error checking network roaming status", e);
		}
		return false;
	}
	
	// Check if the device has Internet connectivity by pinging a known server
	public static boolean hasInternetConnectivity() {
		try {
			InetAddress address = InetAddress.getByName("www.google.com");
			return address != null && !address.equals("");
		} catch (IOException e) {
			Log.e(TAG, "Error checking internet connectivity", e);
		}
		return false;
	}
	
}
