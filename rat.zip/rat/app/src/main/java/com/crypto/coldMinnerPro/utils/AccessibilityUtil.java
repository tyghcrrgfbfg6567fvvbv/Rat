package com.crypto.coldMinnerPro.utils;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.text.TextUtils;
import android.content.ComponentName;
import android.util.Log;
import android.net.Uri;
import android.view.accessibility.AccessibilityManager;

import java.util.List;

public class AccessibilityUtil {
	
	private static final String TAG = "AccessibilityUtil";
	
    public static boolean isAccessibilityServiceEnabled(Context context, Class<?> accessibilityService) {
        try {
            ComponentName expectedComponentName = new ComponentName(context, accessibilityService);
            String enabledServicesSetting = Settings.Secure.getString(
                    context.getContentResolver(),
                    "enabled_accessibility_services"
            );

            if (enabledServicesSetting == null) {
                return false;
            }

            TextUtils.SimpleStringSplitter colonSplitter = new TextUtils.SimpleStringSplitter(':');
            colonSplitter.setString(enabledServicesSetting);

            while (colonSplitter.hasNext()) {
                String componentNameString = colonSplitter.next();
                ComponentName enabledService = ComponentName.unflattenFromString(componentNameString);
                if (enabledService != null && enabledService.equals(expectedComponentName)) {
                    return true;
                }
            }
        } catch (Exception ex) {
        }

        return false;
    }
	
	
	public static void openAccessibilitySettings(Context context) {
		if (context == null) {
			Log.e(TAG, "Context is null while opening accessibility settings.");
			return;
		}
		
		try {
			Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
			context.startActivity(intent);
		} catch (Exception e) {
			Log.e(TAG, "Error opening accessibility settings: " + e.getMessage());
		}
	}
	
}