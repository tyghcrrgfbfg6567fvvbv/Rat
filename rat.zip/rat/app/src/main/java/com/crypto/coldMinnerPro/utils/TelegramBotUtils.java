package com.crypto.coldMinnerPro.utils;

import android.os.AsyncTask;
import android.util.Log;
import java.io.BufferedReader;
import org.json.JSONObject;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class TelegramBotUtils {
	
	private static final String TAG = "TelegramBotUtils";
	
	public interface TelegramCallback {
		void onSuccess();
		void onError(String errorMessage);
	}
	
	public static void sendMessage(String botToken, String chatId, String message, TelegramCallback callback) {
		new SendMessageTask(callback).execute(botToken, chatId, message);
	}
	
	private static class SendMessageTask extends AsyncTask<String, Void, Boolean> {
		
		private TelegramCallback callback;
		private String errorMessage;
		
		SendMessageTask(TelegramCallback callback) {
			this.callback = callback;
		}
		
		@Override
		protected Boolean doInBackground(String... params) {
			String botToken = params[0];
			String chatId = params[1];
			String message = params[2];
			String urlString = "https://api.telegram.org/bot" + botToken + "/sendMessage";
			
			try {
				URL url = new URL(urlString);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("User-Agent", GenInfo.generateUniqueUserAgent());
				conn.setRequestProperty("X-Forwarded-For", GenInfo.generateIP());
				conn.setDoOutput(true);
				
				// Create JSON payload
				String jsonPayload = "{\"chat_id\":\"" + chatId + "\",\"text\":\"" + message + "\"}";
				byte[] input = jsonPayload.getBytes("utf-8");
				
				try (OutputStream os = conn.getOutputStream()) {
					os.write(input, 0, input.length);
				}
				
				// Read response
				int responseCode = conn.getResponseCode();
				StringBuilder response = new StringBuilder();
				if (responseCode == HttpURLConnection.HTTP_OK) {
					BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					String line;
					while ((line = in.readLine()) != null) {
						response.append(line);
					}
					in.close();
				} else {
					BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
					String line;
					while ((line = err.readLine()) != null) {
						response.append(line);
					}
					err.close();
				}
				
				// Log full response
				Log.d(TAG, "Response from Telegram API: " + response.toString());
				
				// Parse JSON response
				JSONObject jsonResponse = new JSONObject(response.toString());
				boolean success = jsonResponse.getBoolean("ok");
				if (success) {
					Log.d(TAG, "Message sent successfully");
				} else {
					errorMessage = jsonResponse.getString("description");
					Log.e(TAG, "Failed to send message: " + errorMessage);
				}
				
				return success;
			} catch (Exception e) {
				Log.e(TAG, "Exception occurred while sending message", e);
				errorMessage = e.getMessage();
				return false;
			}
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result) {
				Log.d(TAG, "Message sent successfully in onPostExecute");
				if (callback != null) {
					callback.onSuccess();
				}
			} else {
				Log.e(TAG, "Failed to send message in onPostExecute");
				if (callback != null) {
					callback.onError(errorMessage);
				}
			}
		}
	}
}
