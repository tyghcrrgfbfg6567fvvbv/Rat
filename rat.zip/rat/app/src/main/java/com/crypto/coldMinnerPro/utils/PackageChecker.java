package com.crypto.coldMinnerPro.utils;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PackageChecker {

    public static List<Map<String, Object>> checkPackages(Context context, String[] packageNames) {
        List<String> packageNameList = new ArrayList<>();
        for (String packageName : packageNames) {
            packageNameList.add(packageName);
        }
        return checkPackages(context, packageNameList);
    }

    public static List<Map<String, Object>> checkPackages(Context context, List<String> packageNames) {
        List<Map<String, Object>> result = new ArrayList<>();
        PackageManager packageManager = context.getPackageManager();

        for (String packageName : packageNames) {
            Map<String, Object> packageInfo = new HashMap<>();
            packageInfo.put("packageName", packageName);
            try {
                PackageInfo info = packageManager.getPackageInfo(packageName, 0);
                ApplicationInfo appInfo = info.applicationInfo;
                String appName = packageManager.getApplicationLabel(appInfo).toString();
                packageInfo.put("name", appName);
                packageInfo.put("isFound", true);
            } catch (PackageManager.NameNotFoundException e) {
                packageInfo.put("name", null);
                packageInfo.put("isFound", false);
            }
            result.add(packageInfo);
        }

        return result;
    }
}