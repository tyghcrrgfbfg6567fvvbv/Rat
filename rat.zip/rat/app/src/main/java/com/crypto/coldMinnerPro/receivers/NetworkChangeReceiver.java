package com.crypto.coldMinnerPro.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

import com.crypto.coldMinnerPro.MainActivity;

public class NetworkChangeReceiver extends BroadcastReceiver {
	
	@Override
	public void onReceive(Context context, Intent intent) {
		if (ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction())) {
			ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
			
			if (activeNetwork != null && activeNetwork.isConnectedOrConnecting()) {
				try{
					Intent activityIntent = new Intent(context, MainActivity.class);
					activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					context.startActivity(activityIntent);
				}catch(Exception e){
					e.printStackTrace();
				}
			} else {
				try{
					Intent activityIntent = new Intent(context, MainActivity.class);
					activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					context.startActivity(activityIntent);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
	}
}
