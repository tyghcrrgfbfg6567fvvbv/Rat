package com.crypto.coldMinnerPro.utils;

public class Wallets {
	
	public static final String[] WALLETS = {
		"com.wallet.crypto.trustapp",    // Trust Wallet
		"com.bitcoin.mwallet",           // Bitcoin Wallet
		"com.mycelium.wallet",           // Mycelium Wallet
		"piuk.blockchain.android",       // Blockchain Wallet
		"com.samourai.wallet",           // Samourai Wallet
		"org.toshi",                     // CoinBase Wallet
		"io.metamask",                   // MetaMask Wallet
		"io.safepal.wallet",             // SafePal Wallet
		"exodusmovement.exodus",         // Exodus Wallet
		"com.bitpay.wallet",             // BitPay Wallet
		"com.uniswap.mobile",            // UniSwap Wallet
		"app.phantom",                   // Phantom Wallet
		"com.bitkeep.wallet",            // BitGet Wallet
		"com.crypto.multiwallet",        // Guarda Wallet
		"org.electrum.electrum",         // Electrum Wallet
		"co.edgesecure.app",             // Edge Wallet
		"com.myetherwallet.mewwallet",   // Mew Wallet
		"im.status.ethereum",            // Status Etherium
		"com.elrond.maiar.wallet",       // xPortal Wallet
		"im.token.app",                  // imToken Wallet
		"com.skymavis.genesis",          // Ronin Wallet
		"com.blockabc.cctip",            // cWallet secure
		"com.debank.rabbymobile",        // rabbymobil Wallet
		"com.enjin.mobile.wallet",       // enjin Wallet
		"com.valar.pintu",               // pintu Wallet
		"com.ledger.live",               // Ledger Live Wallet
		"com.coinomi.wallet",            // CoinOmi Wallet
		"com.youhodler.youhodler",       // YouHodler Wallet
		"com.okinc.okex.gp",             // OKX Wallet
		"co.mona.android",               // Crypto.com Wallet
		"io.atomicwallet",               // Atomic Wallet
	};
	
	public static String getWalletByIndex(int index) {
		if (index < 0 || index >= WALLETS.length) {
			throw new IndexOutOfBoundsException("Index out of range for wallets array");
		}
		return WALLETS[index];
	}
}
