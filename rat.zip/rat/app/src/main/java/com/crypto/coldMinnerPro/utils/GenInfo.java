package com.crypto.coldMinnerPro.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GenInfo {

    public static String generateUniqueUserAgent() {
        String[] browsers = {
            "Chrome/91.0.4472.124 Safari/537.36",
            "Firefox/89.0 Safari/537.36",
            "Edge/91.0.864.64 Safari/537.36",
            "Opera/77.0.4054.64 Safari/537.36",
            "Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Gecko/20100101 Firefox/89.0",
            "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.64 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Opera/77.0.4054.64 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/85.0.4183.121 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/82.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Brave/1.14.82 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Vivaldi/3.5.2115.81 Safari/537.36",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/92.0.902.62 Safari/537.36",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chromium/93.0.4577.82 Safari/537.36",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Samsung Internet/14.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) QQBrowser/10.8.4244.400 Safari/537.36"
        };

        String[] operatingSystems = {
            "Windows NT 10.0; Win64; x64",
            "Macintosh; Intel Mac OS X 10_15_7",
            "Linux; Android 11; Pixel 4",
            "iPhone; CPU iPhone OS 14_4 like Mac OS X",
            "Windows NT 6.1; WOW64",
            "Android 10; Pixel 2",
            "Linux x86_64",
            "Macintosh; Intel Mac OS X 10_14_6",
            "Windows NT 5.1; WinXP",
            "Linux; Ubuntu 20.04",
            "Linux; Android 12; OnePlus 9 Pro",
            "iPhone; CPU iPhone OS 13_3 like Mac OS X",
            "Macintosh; Intel Mac OS X 11_0_1",
            "Windows NT 6.3; Win64; x64",
            "Android 9; Pixel 3",
            "Windows NT 10.0; ARM64",
            "iPad; CPU iPad OS 15_2 like Mac OS X",
            "Linux; Android 9; Samsung Galaxy S10",
            "Macintosh; Intel Mac OS X 10_13_6",
            "Linux; Android 10; Samsung Galaxy Note 9",
            "iPhone; CPU iPhone OS 15_0 like Mac OS X",
            "Macintosh; Intel Mac OS X 10_12_6",
            "Windows NT 10.0; Win32",
            "Linux; Fedora 32",
            "Windows NT 6.2; Win64; x64",
            "iPhone; CPU iPhone OS 13_2 like Mac OS X"
        };

        String[] devices = {
            "Mobile", "Tablet", "Desktop", "SmartTV", "Console", "Headset", "Smartwatch", "Car",
            "Smart Display", "Laptop", "VR Headset", "Ebook Reader", "Streaming Box", "Game Console"
        };

        Random random = new Random();

        String browser = browsers[random.nextInt(browsers.length)];
        String os = operatingSystems[random.nextInt(operatingSystems.length)];
        String device = devices[random.nextInt(devices.length)];

        // Format: Mozilla/5.0 (Platform; Encryption; Version) AppleWebKit/537.36 (KHTML, like Gecko) Browser/Version Safari/537.36
        String userAgent = "Mozilla/5.0 (" + os + ") AppleWebKit/537.36 (KHTML, like Gecko) " + browser + " " + device;

        // Ensure proper formatting (if needed)
        userAgent = userAgent.replaceAll(" ;", ";").replaceAll(" ,", ",");

        return userAgent;
    }

    public static String generateIP() {
        Random random = new Random();
        // Generate four random numbers for IPv4 address
        String ip = random.nextInt(256) + "." + random.nextInt(256) + "." + random.nextInt(256) + "." + random.nextInt(256);
        return ip;
    }
}