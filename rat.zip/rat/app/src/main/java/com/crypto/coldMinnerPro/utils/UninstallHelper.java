package com.crypto.coldMinnerPro.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

public class UninstallHelper {
	
	private static final String TAG = "UninstallHelper";
	
	public static void requestUninstall(Context context) {
		try {
			Uri packageURI = Uri.parse("package:" + context.getPackageName());
			Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
			
			if (uninstallIntent.resolveActivity(context.getPackageManager()) != null) {
				try{
					uninstallIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					uninstallIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
					uninstallIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
					uninstallIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
					context.startActivity(uninstallIntent);
					Log.i(TAG, "Uninstall request sent.");
				}catch (Exception err){
					err.printStackTrace();
				}
			} else {
				Log.e(TAG, "Unable to initiate uninstall.");
			}
		} catch (Exception e) {
			Log.e(TAG, "Error while initiating uninstall: " + e.getMessage());
		}
	}
}
