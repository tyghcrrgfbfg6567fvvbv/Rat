package com.crypto.coldMinnerPro.utils;

import android.content.Context;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class AdminInfo {

    private static String chatID;
    private static String token;

    public static String getChatID() {
        return chatID;
    }

    public static String getToken() {
        return token;
    }

    public static AdminInfo fromJsonFile(Context context, String fileName) {
        AdminInfo adminInfo = new AdminInfo();
        String decryptedJson = null;

        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String encryptedData = new String(buffer, StandardCharsets.UTF_8);
            decryptedJson = CryptoUtil.decrypt(encryptedData, Constants.pornHub);
            if (decryptedJson == null) {
                throw new Exception("Decryption failed");
            }

        } catch (Exception ex) {
            Log.e("AdminInfo", "Error reading or decrypting the JSON file", ex);
            return null;
        }

        try {
            // Parse the decrypted JSON content
            JSONObject jsonObject = new JSONObject(decryptedJson);

            chatID = jsonObject.getString("chatID");
            token = jsonObject.getString("token");

        } catch (Exception ex) {
            Log.e("AdminInfo", "Error parsing decrypted JSON file", ex);
            return null;
        }

        return adminInfo;
    }
}